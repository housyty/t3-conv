﻿# t3-conv portable package

## Requirements

- Tianzheng T20 V9 must be installed on this machine.
- AutoCAD must be installed on this machine.
- The package does not include Tianzheng or AutoCAD files.

## Usage

Default output is compact. Use `--dry-run` to inspect the launch plan and `-d` for internal diagnostics.

Single file:

````powershell
.\t3conv.exe -s "C:\path\in.dwg" -o "C:\path\out_t3.dwg"
````

Single-file and folder-batch `t3conv.log` files are written next to `t3conv.exe` by default.
When `t3conv.log` exceeds 20 MB, new entries are written under `log\t3conv.log.1`, `log\t3conv.log.2`, and so on. After 20 rolled files are full, old rolled logs are cleared and numbering restarts.
Temporary `_t3conv_work` files are created under this package directory and removed after each conversion attempt.

Folder batch:

````powershell
.\t3conv.exe -s "C:\path\dwgs" -o "C:\path\t3-output"
````

Folder-batch summaries are appended to `t3conv.log` as a `batch_summary` block. The Tianzheng CAD host is reused between files and restarted only for timeouts, launch failures, crashes, or explicit host-side failures.

## Configuration

Default `t3conv.ini` can remain fully commented. If auto-detection fails, set:

````ini
[paths]
tangent_root=C:\path\to\TArchT20V9
autocad_root=C:\Program Files\Autodesk\AutoCAD 2020

[fonts]
fontalt=HZTXT.SHX
````

Project fonts go in `fonts`. On startup, `.shx` and `.ttf` files in this package directory are synced into AutoCAD `Fonts` safely.

Generated runtime files are created under `var` after first run and are intentionally not included in this zip.
